<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Character_Terrain extends Model 
{

    protected $table = 'character_terrain';
    public $timestamps = false;

}