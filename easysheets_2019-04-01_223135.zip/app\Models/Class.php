<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Class extends Model 
{

    protected $table = 'class';
    public $timestamps = false;

}