<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Character_Lineage extends Model 
{

    protected $table = 'character_lineage';
    public $timestamps = false;

}