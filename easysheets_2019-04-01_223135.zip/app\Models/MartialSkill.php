<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MartialSkill extends Model 
{

    protected $table = 'martial_skill';
    public $timestamps = false;

}