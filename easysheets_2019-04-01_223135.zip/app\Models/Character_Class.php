<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Character_Class extends Model 
{

    protected $table = 'character_class';
    public $timestamps = false;

}