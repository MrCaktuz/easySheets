<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Character_School extends Model 
{

    protected $table = 'character_school';
    public $timestamps = false;

}