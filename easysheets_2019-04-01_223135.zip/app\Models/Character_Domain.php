<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Character_Domain extends Model 
{

    protected $table = 'character_domaine';
    public $timestamps = false;

}