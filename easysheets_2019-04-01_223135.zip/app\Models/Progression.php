<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Progression extends Model 
{

    protected $table = 'progression';
    public $timestamps = false;

}