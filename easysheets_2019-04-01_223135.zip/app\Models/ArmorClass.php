<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ArmorClass extends Model 
{

    protected $table = 'armor_class';
    public $timestamps = false;

}