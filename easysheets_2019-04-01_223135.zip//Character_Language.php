<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Character_Language extends Model 
{

    protected $table = 'character_language';
    public $timestamps = false;

}