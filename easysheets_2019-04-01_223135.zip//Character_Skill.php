<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Character_Skill extends Model 
{

    protected $table = 'character_skill';
    public $timestamps = false;

}