<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lineage extends Model 
{

    protected $table = 'lineage';
    public $timestamps = false;

}