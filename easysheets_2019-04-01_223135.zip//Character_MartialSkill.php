<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Character_MartialSkill extends Model 
{

    protected $table = 'character_martial_skill';
    public $timestamps = false;

}