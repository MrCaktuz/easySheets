<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SkillType extends Model 
{

    protected $table = 'skill_type';
    public $timestamps = false;

}